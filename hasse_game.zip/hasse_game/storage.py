"""Tiny SQLite-backed leaderboard."""
import os
import sqlite3
import time
from contextlib import closing

DB_PATH = os.environ.get(
    "HASSE_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "instance", "scores.db")
)


def _connect():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init():
    with closing(_connect()) as con, con:
        con.execute(
            """CREATE TABLE IF NOT EXISTS scores (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 name TEXT NOT NULL,
                 score INTEGER NOT NULL,
                 stages INTEGER NOT NULL,
                 created REAL NOT NULL)"""
        )


def add_score(name, score, stages):
    with closing(_connect()) as con, con:
        con.execute(
            "INSERT INTO scores (name, score, stages, created) VALUES (?, ?, ?, ?)",
            (name, int(score), int(stages), time.time()),
        )


def top(limit=10):
    with closing(_connect()) as con:
        rows = con.execute(
            "SELECT name, score, stages FROM scores ORDER BY score DESC, stages DESC, created ASC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(r) for r in rows]
