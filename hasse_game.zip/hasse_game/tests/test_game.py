"""Property-based style tests: every check runs on freshly generated posets."""
import os
import random
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["HASSE_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")

import generator  # noqa: E402
from poset import Poset, PosetError, check_diagram, parse_custom, suggest_hint  # noqa: E402


def brute_force_covers(p):
    out = set()
    for a in p.nodes:
        for b in p.nodes:
            if a != b and p.less(a, b):
                if not any(p.less(a, c) and p.less(c, b) for c in p.nodes):
                    out.add((a, b))
    return out


def perfect_layout(p):
    """Height = longest chain below the element, so greater elements sit higher."""
    rank = {}

    def r(n):
        if n not in rank:
            rank[n] = 0 if not p.down[n] else 1 + max(r(d) for d in p.down[n])
        return rank[n]

    return {n: {"x": 50 * i, "y": 500 - 60 * r(n)} for i, n in enumerate(p.nodes)}


class PosetTests(unittest.TestCase):
    def test_covers_match_brute_force_on_random_posets(self):
        for seed in range(200):
            rng = random.Random(seed)
            n = rng.randint(3, 14)
            p, _ = generator.random_poset(n, rng.uniform(0.1, 0.7), rng)
            self.assertEqual(set(p.covers), brute_force_covers(p), f"seed {seed}")

    def test_generated_modes_are_valid(self):
        for seed in range(60):
            rng = random.Random(seed)
            for mode in generator.MODES:
                out = generator.generate(mode, rng, size=rng.randint(3, 14), density=0.4)
                self.assertEqual(set(out["poset"].covers), brute_force_covers(out["poset"]))

    def test_same_seed_same_puzzle_different_seed_differs(self):
        a = generator.stage_puzzle(5, 42)["poset"]
        b = generator.stage_puzzle(5, 42)["poset"]
        self.assertEqual((a.nodes, a.covers), (b.nodes, b.covers))
        variants = {tuple(generator.stage_puzzle(5, s)["poset"].covers) for s in range(20)}
        self.assertGreater(len(variants), 5)

    def test_cycle_is_rejected(self):
        with self.assertRaises(PosetError):
            Poset(["a", "b", "c"], [("a", "b"), ("b", "c"), ("c", "a")])

    def test_custom_parsing_formats(self):
        nodes, pairs = parse_custom("x", "a < b < c\nd > c\ne, a\nf -> e # note\ng ≤ f; h >= g")
        self.assertEqual(set(nodes), set("xabcdefgh"))
        self.assertIn(("a", "b"), pairs)
        self.assertIn(("b", "c"), pairs)
        self.assertIn(("c", "d"), pairs)
        self.assertIn(("e", "a"), pairs)
        self.assertIn(("f", "e"), pairs)
        self.assertIn(("g", "h"), pairs)

    def test_custom_input_arbitrary_names(self):
        nodes, pairs = parse_custom("", "apple < banana\nbanana < cherry\napple < cherry")
        p = Poset(nodes, pairs)
        self.assertEqual(p.covers, [("apple", "banana"), ("banana", "cherry")])

    def test_bad_input_gives_friendly_errors(self):
        for rel in ("a <", "a < b < a", "onlyone"):
            with self.assertRaises(PosetError):
                p = Poset(*parse_custom("", rel))

    def test_perfect_diagram_is_solved_for_random_puzzles(self):
        for seed in range(100):
            rng = random.Random(seed)
            p, _ = generator.random_poset(rng.randint(3, 12), 0.4, rng)
            edges = [[a, b] for a, b in p.covers]
            res = check_diagram(p, perfect_layout(p), edges)
            self.assertTrue(res["solved"], (seed, res["messages"]))

    def test_mistakes_are_detected(self):
        p = Poset(list("abc"), [("a", "b"), ("b", "c"), ("a", "c")])
        pos = perfect_layout(p)
        self.assertFalse(check_diagram(p, pos, [["a", "b"]])["solved"])              # missing
        redundant = check_diagram(p, pos, [["a", "b"], ["b", "c"], ["a", "c"]])
        self.assertIn("redundant", redundant["edge_status"])                         # transitive edge
        flipped = dict(pos, a=pos["c"], c=pos["a"])
        self.assertFalse(check_diagram(p, flipped, [["a", "b"], ["b", "c"]])["solved"])  # upside down
        self.assertTrue(check_diagram(p, pos, [["b", "a"], ["c", "b"]])["solved"])   # edge order irrelevant

    def test_hint_points_at_real_missing_edge(self):
        p = Poset(list("abc"), [("a", "b"), ("b", "c")])
        tip = suggest_hint(p, perfect_layout(p), [])
        self.assertEqual(tip["type"], "edge")
        self.assertIn(tuple(sorted(tip["nodes"])), [("a", "b"), ("b", "c")])


class ApiTests(unittest.TestCase):
    def setUp(self):
        import app as app_module
        self.client = app_module.app.test_client()

    def test_custom_puzzle_roundtrip(self):
        r = self.client.post("/api/puzzle", json={"mode": "custom", "nodes": "", "relations": "x<y\ny<z\nx<z\nx<w"})
        self.assertEqual(r.status_code, 200)
        pz = r.get_json()
        self.assertNotIn("covers", pz)
        pos = {"x": {"x": 0, "y": 400}, "y": {"x": 0, "y": 300}, "z": {"x": 0, "y": 200}, "w": {"x": 90, "y": 300}}
        ok = self.client.post(f"/api/puzzle/{pz['id']}/check",
                              json={"positions": pos, "edges": [["x", "y"], ["y", "z"], ["x", "w"]]}).get_json()
        self.assertTrue(ok["solved"])
        self.assertGreater(ok["score"], 0)

    def test_campaign_progresses_and_leaderboard(self):
        run = self.client.post("/api/run").get_json()["run_id"]
        pz = self.client.post("/api/puzzle", json={"mode": "stage", "run_id": run}).get_json()
        self.assertEqual(pz["stage"], 1)
        # solve it by asking the server for hints repeatedly is impractical; use the poset directly
        import app as app_module
        poset = app_module.PUZZLES[pz["id"]]["poset"]
        res = self.client.post(f"/api/puzzle/{pz['id']}/check", json={
            "positions": perfect_layout(poset), "edges": [list(c) for c in poset.covers]}).get_json()
        self.assertTrue(res["solved"])
        self.assertEqual(res["run"]["stage"], 1)
        pz2 = self.client.post("/api/puzzle", json={"mode": "stage", "run_id": run}).get_json()
        self.assertEqual(pz2["stage"], 2)
        top = self.client.post("/api/leaderboard", json={"run_id": run, "name": "tester"}).get_json()
        self.assertEqual(top[0]["name"], "tester")

    def test_generate_with_user_ingredients(self):
        r = self.client.post("/api/puzzle", json={"mode": "divisibility", "values": "1, 2, 3, 6, 12, 18"}).get_json()
        self.assertEqual(sorted(r["nodes"], key=int), ["1", "2", "3", "6", "12", "18"])
        r = self.client.post("/api/puzzle", json={"mode": "subset", "elements": "x,y,z", "size": 8}).get_json()
        self.assertEqual(len(r["nodes"]), 8)
        r = self.client.post("/api/puzzle", json={"mode": "random", "labels": "red,green,blue,gold,teal"}).get_json()
        self.assertEqual(sorted(r["nodes"]), ["blue", "gold", "green", "red", "teal"])

    def test_errors_are_reported_not_raised(self):
        r = self.client.post("/api/puzzle", json={"mode": "custom", "relations": "a<b\nb<a"})
        self.assertEqual(r.status_code, 400)
        self.assertIn("cycle", r.get_json()["error"])
        self.assertEqual(self.client.post("/api/puzzle/nope/check", json={}).status_code, 404)


if __name__ == "__main__":
    unittest.main()
