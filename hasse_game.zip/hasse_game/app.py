"""Hasse Diagram Builder - Flask backend.

Run with:  python app.py   (then open http://127.0.0.1:5000)
"""
import random
import secrets
import threading
import time
from collections import OrderedDict

from flask import Flask, jsonify, render_template, request

import generator
import storage
from poset import PosetError, Poset, check_diagram, parse_custom, suggest_hint

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024  # inputs are small; reject anything huge

_lock = threading.Lock()
PUZZLES = OrderedDict()   # puzzle_id -> puzzle dict (kept in memory, capped)
RUNS = {}                 # run_id -> {"score", "stage", "created"}
MAX_PUZZLES = 1000
MAX_RUNS = 1000

storage.init()


# ------------------------------------------------------------------ helpers

def fail(message, status=400):
    return jsonify({"error": message}), status


def body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def as_int(value, default, lo, hi):
    try:
        return max(lo, min(hi, int(value)))
    except (TypeError, ValueError):
        return default


def as_float(value, default, lo, hi):
    try:
        return max(lo, min(hi, float(value)))
    except (TypeError, ValueError):
        return default


def max_score(n):
    return 40 + 20 * n


def public_puzzle(pz):
    return {
        "id": pz["id"],
        "mode": pz["mode"],
        "seed": pz["seed"],
        "nodes": pz["poset"].nodes,
        "given": [list(p) for p in pz["given"]],
        "description": pz["description"],
        "max_score": max_score(len(pz["poset"].nodes)),
        "stage": pz.get("stage"),
        "run": run_info(pz.get("run_id")),
    }


def run_info(run_id):
    run = RUNS.get(run_id)
    return {"stage": run["stage"], "score": run["score"]} if run else None


def store_puzzle(pz):
    with _lock:
        PUZZLES[pz["id"]] = pz
        while len(PUZZLES) > MAX_PUZZLES:
            PUZZLES.popitem(last=False)


def get_puzzle(pid):
    pz = PUZZLES.get(pid)
    if not pz:
        raise LookupError("That puzzle has expired. Start a new one.")
    return pz


# ------------------------------------------------------------------ routes

@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/run")
def new_run():
    with _lock:
        if len(RUNS) >= MAX_RUNS:
            oldest = min(RUNS, key=lambda k: RUNS[k]["created"])
            del RUNS[oldest]
        run_id = secrets.token_urlsafe(9)
        RUNS[run_id] = {"score": 0, "stage": 0, "created": time.time()}
    return jsonify({"run_id": run_id, "run": run_info(run_id)})


@app.post("/api/puzzle")
def new_puzzle():
    data = body()
    mode = str(data.get("mode", "stage"))
    seed = data.get("seed")
    seed = as_int(seed, secrets.randbelow(10**6), 0, 10**9) if seed not in (None, "") else secrets.randbelow(10**6)
    rng = random.Random(seed)
    run_id = data.get("run_id")
    stage = None

    try:
        if mode == "custom":
            nodes, pairs = parse_custom(data.get("nodes", ""), data.get("relations", ""))
            poset = Poset(nodes, pairs)
            built = {
                "poset": poset,
                "given": pairs,
                "description": "Draw the Hasse diagram for the relations you entered. "
                               "Relations are closed under transitivity.",
            }
        elif mode == "stage":
            run = RUNS.get(run_id)
            if not run:
                return fail("Start a campaign run first.")
            stage = run["stage"] + 1
            built = generator.stage_puzzle(stage, seed)
            mode = "stage"
        else:
            built = generator.generate(
                mode, rng,
                size=as_int(data.get("size"), 6, 3, 16),
                density=as_float(data.get("density"), 0.35, 0.05, 0.9),
                labels=data.get("labels"),
                values=data.get("values"),
                elements=data.get("elements"),
            )
    except PosetError as e:
        return fail(str(e))

    pz = {
        "id": secrets.token_urlsafe(9),
        "mode": mode,
        "seed": seed,
        "poset": built["poset"],
        "given": built["given"],
        "description": built["description"],
        "fails": 0,
        "hints": 0,
        "solved": False,
        "score": 0,
        "stage": stage,
        "run_id": run_id if mode == "stage" else None,
    }
    store_puzzle(pz)
    return jsonify(public_puzzle(pz))


def _diagram_args():
    data = body()
    return data.get("positions") or {}, data.get("edges") or []


def _strip(result):
    return {k: v for k, v in result.items() if not k.startswith("_")}


@app.post("/api/puzzle/<pid>/check")
def check(pid):
    try:
        pz = get_puzzle(pid)
        positions, edges = _diagram_args()
        result = check_diagram(pz["poset"], positions, edges)
    except LookupError as e:
        return fail(str(e), 404)
    except PosetError as e:
        return fail(str(e))

    with _lock:
        if result["solved"]:
            if not pz["solved"]:
                pz["solved"] = True
                pz["score"] = max(10, max_score(len(pz["poset"].nodes)) - 10 * pz["fails"] - 25 * pz["hints"])
                run = RUNS.get(pz["run_id"])
                if run and pz["mode"] == "stage":
                    run["score"] += pz["score"]
                    run["stage"] += 1
        else:
            pz["fails"] += 1

    out = _strip(result)
    out.update(score=pz["score"], fails=pz["fails"], hints=pz["hints"],
               max_score=max_score(len(pz["poset"].nodes)), run=run_info(pz.get("run_id")))
    return jsonify(out)


@app.post("/api/puzzle/<pid>/hint")
def hint(pid):
    try:
        pz = get_puzzle(pid)
        positions, edges = _diagram_args()
        tip = suggest_hint(pz["poset"], positions, edges)
    except LookupError as e:
        return fail(str(e), 404)
    except PosetError as e:
        return fail(str(e))
    if tip["type"] != "none" and not pz["solved"]:
        with _lock:
            pz["hints"] += 1
    tip["hints"] = pz["hints"]
    return jsonify(tip)


@app.get("/api/leaderboard")
def leaderboard():
    return jsonify(storage.top(10))


@app.post("/api/leaderboard")
def submit_score():
    data = body()
    run = RUNS.get(data.get("run_id"))
    name = str(data.get("name", "")).strip()[:20]
    if not run or run["stage"] == 0:
        return fail("Clear at least one stage before banking a score.")
    if not name:
        return fail("Enter a name for the leaderboard.")
    storage.add_score(name, run["score"], run["stage"])
    return jsonify(storage.top(10))


if __name__ == "__main__":
    app.run(debug=True)
