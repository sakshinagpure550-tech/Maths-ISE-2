# Hasse Diagram Builder

A drag-and-drop puzzle game. Given a partial order, drag the elements into place and
draw exactly the **cover relations** (the edges of the Hasse diagram): greater
elements sit higher, and no edge may be implied by transitivity.

Backend: Python + Flask. Frontend: HTML, CSS, Bootstrap 5 (CDN), vanilla JS + SVG.

## Run

    pip install -r requirements.txt
    python app.py
    # open http://127.0.0.1:5000

Run the tests (all use freshly generated random posets):

    python -m unittest discover -s tests -v

## Nothing is hard-coded

There are no stored levels or answer keys. Every puzzle comes from one of three sources:

| Source | What the player controls |
|---|---|
| **Campaign** | Stage number and optional seed. Size and density grow each stage. |
| **Generate** | Kind of order (random / divisibility / subset inclusion), size 3-16, density, seed, plus optional own element names, own integers, or own base set. |
| **Custom** | Any element names (up to 12 characters) and any relations. |

Custom relation syntax (one per line, or separated by `;`):

    a < b          a <= b        a ≤ b        a -> b
    b > a          b >= a
    a < b < c      chains
    a, b           pair meaning a is below b
    # comment

Elements mentioned in a relation are added automatically. Cyclic input is rejected with a
message showing the cycle (a partial order must be antisymmetric).

## How answers are judged (poset.py)

1. Build the transitive closure of the given pairs.
2. Cover relations = pairs `a < b` with no `c` such that `a < c < b`.
3. A diagram is solved when the drawn edges equal the cover set, each edge is oriented by
   height (the greater element is higher), and every relation `a < b` puts `a` strictly below `b`.

The server never sends the cover set to the browser; it only reports which drawn edges are
wrong and why (redundant by transitivity, upside-down, incomparable, horizontal) and how many are missing.

## Scoring

`max = 40 + 20 x elements`; each failed check costs 10, each hint 25 (minimum 10). Campaign scores accumulate
server-side per run and can be banked to an SQLite leaderboard (`instance/scores.db`).

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/run` | Start a campaign run |
| POST | `/api/puzzle` | Create a puzzle: `mode` = `stage`, `random`, `divisibility`, `subset`, `custom` |
| POST | `/api/puzzle/<id>/check` | Submit `positions` and `edges` for judging |
| POST | `/api/puzzle/<id>/hint` | Get one next step |
| GET/POST | `/api/leaderboard` | Top scores / bank a run |

## Files

    app.py         Flask routes, scoring, run tracking
    poset.py       parsing, closure, covers, diagram validation, hints
    generator.py   seeded random / divisibility / subset generators, stage scaling
    storage.py     SQLite leaderboard
    templates/     index.html (Bootstrap layout)
    static/        style.css, game.js (SVG board, drag and drop)
    tests/         randomised unit and API tests
