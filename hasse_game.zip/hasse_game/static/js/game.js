(() => {
  "use strict";

  const SVGNS = "http://www.w3.org/2000/svg";
  const W = 900, H = 600, TRAY_Y = 480, NODE_H = 34;
  const $ = (s) => document.querySelector(s);
  const svg = $("#board");

  const state = {
    puzzle: null,
    pos: {},            // node -> {x, y}
    edges: [],          // [{a, b, status}]
    tool: "move",
    linkFrom: null,
    drag: null,
    runId: null,
    lastPayload: null,
    solved: false,
    hinted: new Set(),
    busy: false,
  };

  // ------------------------------------------------------------ helpers

  async function api(path, method = "GET", body) {
    const res = await fetch(path, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    });
    let data = {};
    try { data = await res.json(); } catch (e) { /* ignore */ }
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  }

  function el(name, attrs = {}, parent) {
    const node = document.createElementNS(SVGNS, name);
    for (const [k, v] of Object.entries(attrs)) node.setAttribute(k, v);
    if (parent) parent.appendChild(node);
    return node;
  }

  function h(tag, props = {}, ...children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === "class") node.className = v;
      else if (k.startsWith("on")) node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v);
    }
    for (const c of children) node.append(c);
    return node;
  }

  const size = (label) => ({ w: Math.max(42, label.length * 8 + 22), h: NODE_H });
  const shuffle = (arr) => {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  };
  const onBoard = (n) => state.pos[n].y < TRAY_Y - 10;

  function svgPoint(evt) {
    const pt = svg.createSVGPoint();
    pt.x = evt.clientX; pt.y = evt.clientY;
    return pt.matrixTransform(svg.getScreenCTM().inverse());
  }

  // ------------------------------------------------------------ static board layers

  const defs = el("defs", {}, svg);
  const marker = el("marker", { id: "arrow", viewBox: "0 0 10 10", refX: 8, refY: 5, markerWidth: 7, markerHeight: 7, orient: "auto-start-reverse" }, defs);
  el("path", { d: "M0 0 L10 5 L0 10 z", fill: "#5d6f7b" }, marker);
  const pattern = el("pattern", { id: "gridpat", width: 30, height: 30, patternUnits: "userSpaceOnUse" }, defs);
  el("path", { d: "M30 0 H0 V30", fill: "none", stroke: "#d3dce1", "stroke-width": 1 }, pattern);

  el("rect", { x: 0, y: 0, width: W, height: H, fill: "url(#gridpat)" }, svg);
  el("rect", { class: "tray", x: 0, y: TRAY_Y, width: W, height: H - TRAY_Y }, svg);
  el("line", { class: "tray-line", x1: 0, x2: W, y1: TRAY_Y, y2: TRAY_Y }, svg);
  const trayNote = el("text", { class: "board-note", x: W - 12, y: TRAY_Y + 20, "text-anchor": "end" }, svg);
  trayNote.textContent = "Tray: drag nodes above this line";
  el("line", { class: "axis", x1: 22, x2: 22, y1: TRAY_Y - 18, y2: 36 }, svg);
  const axisNote = el("text", { class: "board-note", x: 34, y: 34 }, svg);
  axisNote.textContent = "greater";
  const emptyNote = el("text", { class: "board-note", x: W / 2, y: TRAY_Y / 2, "text-anchor": "middle", style: "font-size:18px" }, svg);
  emptyNote.textContent = "Loading puzzle…";
  const layerEdges = el("g", {}, svg);
  const layerNodes = el("g", {}, svg);

  // ------------------------------------------------------------ rendering

  function render() {
    layerEdges.replaceChildren();
    layerNodes.replaceChildren();
    svg.classList.toggle("link-mode", state.tool === "link");
    svg.classList.toggle("solved", state.solved);
    if (!state.puzzle) return;
    emptyNote.textContent = "";

    state.edges.forEach((e, i) => {
      const a = state.pos[e.a], b = state.pos[e.b];
      const coords = { x1: a.x, y1: a.y, x2: b.x, y2: b.y };
      el("line", { class: "edge-hit", "data-edge": i, ...coords }, layerEdges);
      el("line", { class: "edge " + (e.status || ""), ...coords }, layerEdges);
    });

    for (const name of state.puzzle.nodes) {
      const p = state.pos[name], s = size(name);
      const cls = ["node"];
      if (state.linkFrom === name) cls.push("selected");
      if (state.hinted.has(name)) cls.push("hinted");
      if (state.drag && state.drag.name === name) cls.push("dragging");
      const g = el("g", { class: cls.join(" "), "data-node": name, transform: `translate(${p.x},${p.y})` }, layerNodes);
      el("rect", { x: -s.w / 2, y: -s.h / 2, width: s.w, height: s.h, rx: 9 }, g);
      const t = el("text", {}, g);
      t.textContent = name;
    }
  }

  function layoutTray() {
    const names = shuffle([...state.puzzle.nodes]);
    let x = 16, row = 0;
    for (const n of names) {
      const s = size(n);
      if (x + s.w > W - 16) { x = 16; row++; }
      state.pos[n] = { x: x + s.w / 2, y: TRAY_Y + 46 + row * 46 };
      x += s.w + 12;
    }
  }

  function invalidate() {
    state.edges.forEach((e) => { e.status = null; });
  }

  function setTool(tool) {
    state.tool = tool;
    state.linkFrom = null;
    $("#tool-move").classList.toggle("active", tool === "move");
    $("#tool-link").classList.toggle("active", tool === "link");
    $("#tool-hint").textContent = tool === "move"
      ? "Drag nodes into the diagram. Greater elements go higher."
      : "Click one node, then another, to add or remove an edge. Click an edge to delete it.";
    render();
  }

  // ------------------------------------------------------------ board interaction

  function toggleEdge(a, b) {
    const idx = state.edges.findIndex((e) => (e.a === a && e.b === b) || (e.a === b && e.b === a));
    if (idx >= 0) state.edges.splice(idx, 1);
    else state.edges.push({ a, b, status: null });
    invalidate();
  }

  svg.addEventListener("pointerdown", (evt) => {
    if (!state.puzzle || state.solved) return;
    const edgeEl = evt.target.closest("[data-edge]");
    const nodeEl = evt.target.closest("[data-node]");
    if (edgeEl) {
      state.edges.splice(Number(edgeEl.dataset.edge), 1);
      invalidate(); render();
      return;
    }
    if (!nodeEl) {
      if (state.linkFrom) { state.linkFrom = null; render(); }
      return;
    }
    const name = nodeEl.dataset.node;
    if (state.tool === "link") {
      if (!state.linkFrom) state.linkFrom = name;
      else if (state.linkFrom === name) state.linkFrom = null;
      else { toggleEdge(state.linkFrom, name); state.linkFrom = null; }
      render();
      return;
    }
    const p = svgPoint(evt);
    state.drag = { name, dx: p.x - state.pos[name].x, dy: p.y - state.pos[name].y };
    svg.setPointerCapture(evt.pointerId);
    evt.preventDefault();
    render();
  });

  svg.addEventListener("pointermove", (evt) => {
    if (!state.drag) return;
    const p = svgPoint(evt);
    const s = size(state.drag.name);
    state.pos[state.drag.name] = {
      x: Math.max(s.w / 2, Math.min(W - s.w / 2, p.x - state.drag.dx)),
      y: Math.max(NODE_H / 2, Math.min(H - NODE_H / 2, p.y - state.drag.dy)),
    };
    invalidate();
    render();
  });

  const endDrag = () => { if (state.drag) { state.drag = null; render(); } };
  svg.addEventListener("pointerup", endDrag);
  svg.addEventListener("pointercancel", endDrag);

  document.addEventListener("keydown", (evt) => {
    if (evt.target.closest("input, textarea, select")) return;
    if (evt.key === "l" || evt.key === "L") setTool("link");
    if (evt.key === "m" || evt.key === "M") setTool("move");
    if (evt.key === "Escape" && state.linkFrom) { state.linkFrom = null; render(); }
  });

  $("#tool-move").addEventListener("click", () => setTool("move"));
  $("#tool-link").addEventListener("click", () => setTool("link"));
  $("#btn-clear-edges").addEventListener("click", () => {
    if (state.solved) return;
    state.edges = []; render();
  });
  $("#btn-reset-nodes").addEventListener("click", () => {
    if (!state.puzzle || state.solved) return;
    layoutTray(); state.edges = []; render();
  });

  // ------------------------------------------------------------ feedback panel

  function feedback(kind, title, lines = [], extra) {
    const box = $("#feedback");
    box.replaceChildren();
    const wrap = h("div", { class: "msg-" + kind }, h("strong", {}, title));
    if (lines.length) wrap.append(h("ul", {}, ...lines.map((l) => h("li", {}, l))));
    if (extra) wrap.append(extra);
    box.append(wrap);
  }

  function setStats() {
    const p = state.puzzle;
    $("#stat-stage").textContent = p && p.stage ? p.stage : "–";
  }

  // ------------------------------------------------------------ puzzle lifecycle

  function showRelations(pz) {
    const box = $("#pz-relations");
    box.replaceChildren();
    const groups = new Map();
    for (const [lo, hi] of pz.given) {
      if (!groups.has(lo)) groups.set(lo, []);
      groups.get(lo).push(hi);
    }
    for (const [lo, his] of groups) {
      box.append(h("span", { class: "rel" }, h("span", { class: "lo" }, lo), " ≤ " + his.join(", ")));
    }
  }

  function loadPuzzle(pz) {
    state.puzzle = pz;
    state.edges = [];
    state.solved = false;
    state.linkFrom = null;
    state.hinted.clear();
    layoutTray();
    const modeName = { stage: "Campaign", random: "Random order", divisibility: "Divisibility order", subset: "Inclusion order", custom: "Your relations" }[pz.mode] || pz.mode;
    $("#pz-title").textContent = pz.stage ? `Stage ${pz.stage}: ${modeName}` : modeName;
    $("#pz-meta").textContent = `${pz.nodes.length} elements · seed ${pz.seed}`;
    $("#pz-desc").textContent = pz.description;
    showRelations(pz);
    $("#btn-check").disabled = false;
    $("#btn-hint").disabled = false;
    feedback("info", "Place every node above the tray line and connect the covering pairs.");
    setStats();
    if (pz.run) $("#stat-score").textContent = pz.run.score;
    setTool("move");
  }

  async function startPuzzle(payload) {
    if (state.busy) return;
    state.busy = true;
    try {
      const pz = await api("/api/puzzle", "POST", payload);
      state.lastPayload = payload;
      loadPuzzle(pz);
      return true;
    } catch (err) {
      feedback("bad", "Could not build that puzzle", [err.message]);
      return false;
    } finally {
      state.busy = false;
    }
  }

  async function newRun() {
    const r = await api("/api/run", "POST");
    state.runId = r.run_id;
    $("#stat-score").textContent = "0";
    await startPuzzle({ mode: "stage", run_id: state.runId });
  }

  const readSeed = (id) => {
    const v = $(id).value.trim();
    return v === "" ? undefined : v;
  };

  $("#btn-new-run").addEventListener("click", newRun);
  $("#btn-skip").addEventListener("click", () => {
    if (!state.runId) return newRun();
    startPuzzle({ mode: "stage", run_id: state.runId, seed: readSeed("#camp-seed") });
  });

  // ------------------------------------------------------------ check / hint

  function diagramPayload() {
    return { positions: state.pos, edges: state.edges.map((e) => [e.a, e.b]) };
  }

  $("#btn-check").addEventListener("click", async () => {
    if (!state.puzzle || state.solved) return;
    const off = state.puzzle.nodes.filter((n) => !onBoard(n));
    if (off.length) {
      feedback("warn", `${off.length} node${off.length > 1 ? "s are" : " is"} still in the tray.`,
        ["Drag every node above the dashed line before checking."]);
      return;
    }
    try {
      const r = await api(`/api/puzzle/${state.puzzle.id}/check`, "POST", diagramPayload());
      r.edge_status.forEach((s, i) => { if (state.edges[i]) state.edges[i].status = s; });
      if (r.run) $("#stat-score").textContent = r.run.score;
      if (r.solved) {
        state.solved = true;
        const next = h("button", { class: "btn btn-sm btn-primary mt-2" },
          state.puzzle.mode === "stage" ? "Next stage" : "Another puzzle like this");
        next.addEventListener("click", nextAfterSolve);
        feedback("ok", `Solved! +${r.score} points`,
          [`Every covering relation is drawn and nothing extra. (${r.fails} failed check${r.fails === 1 ? "" : "s"}, ${r.hints} hint${r.hints === 1 ? "" : "s"})`],
          next);
        $("#btn-check").disabled = true;
        $("#btn-hint").disabled = true;
        render();
      } else {
        const c = r.counts;
        feedback("bad", "Not quite yet", [
          `${c.ok} correct edge${c.ok === 1 ? "" : "s"}, ${c.bad} wrong, ${c.missing} missing.`,
          ...r.messages,
        ]);
        render();
      }
    } catch (err) {
      feedback("bad", "Check failed", [err.message]);
    }
  });

  function nextAfterSolve() {
    if (state.puzzle.mode === "stage") {
      startPuzzle({ mode: "stage", run_id: state.runId, seed: readSeed("#camp-seed") });
    } else if (state.puzzle.mode === "custom") {
      feedback("info", "Edit your relations in the Custom tab to build another one.");
    } else {
      const p = { ...state.lastPayload };
      delete p.seed;
      startPuzzle(p);
    }
  }

  $("#btn-hint").addEventListener("click", async () => {
    if (!state.puzzle || state.solved) return;
    const off = state.puzzle.nodes.filter((n) => !onBoard(n));
    if (off.length) {
      feedback("warn", "Move all nodes into the diagram first.", ["Hints need a full placement to inspect."]);
      return;
    }
    try {
      const tip = await api(`/api/puzzle/${state.puzzle.id}/hint`, "POST", diagramPayload());
      state.hinted = new Set(tip.nodes || []);
      feedback("info", "Hint", [tip.text]);
      render();
      setTimeout(() => { state.hinted.clear(); render(); }, 4000);
    } catch (err) {
      feedback("bad", "Hint failed", [err.message]);
    }
  });

  // ------------------------------------------------------------ forms

  const extraLabels = {
    random: ["Your own element names (optional)", "e.g. red, green, blue, gold", "labels"],
    divisibility: ["Your own integers (optional)", "e.g. 1, 2, 3, 6, 12, 18", "values"],
    subset: ["Your own base elements (optional, up to 5)", "e.g. x, y, z", "elements"],
  };

  function syncGenerateForm() {
    const mode = $("#gen-mode").value;
    $("#gen-extra-label").textContent = extraLabels[mode][0];
    $("#gen-extra").placeholder = extraLabels[mode][1];
    $("#gen-density-wrap").hidden = mode !== "random";
  }
  $("#gen-mode").addEventListener("change", syncGenerateForm);
  $("#gen-density").addEventListener("input", (e) => { $("#gen-density-val").textContent = e.target.value; });
  syncGenerateForm();

  $("#form-generate").addEventListener("submit", (evt) => {
    evt.preventDefault();
    const mode = $("#gen-mode").value;
    const payload = {
      mode,
      size: Number($("#gen-size").value),
      density: Number($("#gen-density").value),
      seed: readSeed("#gen-seed"),
    };
    const extra = $("#gen-extra").value.trim();
    if (extra) payload[extraLabels[mode][2]] = extra;
    startPuzzle(payload);
  });

  $("#form-custom").addEventListener("submit", (evt) => {
    evt.preventDefault();
    startPuzzle({ mode: "custom", nodes: $("#cus-nodes").value, relations: $("#cus-rel").value });
  });

  // ------------------------------------------------------------ leaderboard

  async function loadBoard() {
    try {
      const rows = await api("/api/leaderboard");
      const list = $("#leaderboard");
      list.replaceChildren();
      if (!rows.length) { list.append(h("li", { class: "text-secondary" }, "No scores yet.")); return; }
      rows.forEach((r) => list.append(h("li", {}, `${r.name} · ${r.stages} stage${r.stages === 1 ? "" : "s"}`, h("span", { class: "pts" }, String(r.score)))));
    } catch (e) { /* leaderboard is optional */ }
  }

  $("#btn-bank").addEventListener("click", async () => {
    try {
      await api("/api/leaderboard", "POST", { run_id: state.runId, name: $("#lb-name").value });
      feedback("ok", "Score banked.", ["Your run score is on the leaderboard."]);
      loadBoard();
    } catch (err) {
      feedback("warn", err.message);
    }
  });

  // ------------------------------------------------------------ boot

  loadBoard();
  newRun().catch((err) => feedback("bad", "Could not reach the server", [err.message]));
})();
